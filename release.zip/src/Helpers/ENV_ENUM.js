const ENV_ENUM = {
  QA: {
    dbName: "thundertechsol_dboard_qa",
  },
  UAT: {
    dbName: "thundertechsol_dboard_uat",
  },
  PROD: {
    dbName: "thundertechsol_mab_prod",
  },
};

module.exports = ENV_ENUM;
